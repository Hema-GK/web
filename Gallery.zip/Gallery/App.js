
import './App.css';
import Gallery from './Gallery';

function App() {
  return (
    <div className="App">
      <Gallery></Gallery>
    </div>
  );
}

export default App;
